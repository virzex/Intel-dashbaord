import os
import re
import base64
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlsplit
from datetime import datetime, timedelta

import requests
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

if not ENV_PATH.is_file():
    raise FileNotFoundError(f"Missing configuration: {ENV_PATH}")

load_dotenv(ENV_PATH, override=True)

MYTHIC_GRAPHQL_URL = os.getenv("MYTHIC_GRAPHQL_URL", "").strip().rstrip("/") + "/"
MYTHIC_API_TOKEN = os.getenv("MYTHIC_API_TOKEN", "").strip()

tls_setting = os.getenv("MYTHIC_VERIFY_TLS", "true").strip().lower()
if tls_setting not in {"true", "false"}:
    raise ValueError("MYTHIC_VERIFY_TLS must be true or false.")
VERIFY_TLS = tls_setting == "true"

url = urlsplit(MYTHIC_GRAPHQL_URL)
if url.scheme not in {"http", "https"} or not url.hostname:
    raise ValueError("Set a valid MYTHIC_GRAPHQL_URL in .env.")

if not MYTHIC_API_TOKEN:
    raise ValueError("Set MYTHIC_API_TOKEN in .env.")


def headers() -> Dict[str, str]:
    return {
        "Content-Type": "application/json",
        "apitoken": MYTHIC_API_TOKEN,
    }


def graphql(
    query: str,
    variables: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    response = requests.post(
        MYTHIC_GRAPHQL_URL,
        headers=headers(),
        json={"query": query, "variables": variables or {}},
        verify=VERIFY_TLS,
        timeout=(10, 30),
        allow_redirects=False,
    )

    if 300 <= response.status_code < 400:
        raise RuntimeError("GraphQL endpoint redirected. Check MYTHIC_GRAPHQL_URL.")

    response.raise_for_status()

    try:
        body = response.json()
    except ValueError as exc:
        raise RuntimeError("GraphQL returned a non-JSON response.") from exc

    if not isinstance(body, dict):
        raise RuntimeError("GraphQL returned an invalid response.")

    if body.get("errors"):
        messages = "; ".join(
            error.get("message", "GraphQL request failed")
            for error in body["errors"]
        )
        raise RuntimeError(messages)

    data = body.get("data")
    if not isinstance(data, dict):
        raise RuntimeError("GraphQL response contains no data.")

    return data


CALLBACK_QUERY = """
query ActiveCallbacks {
  callback(where: {active: {_eq: true}}, order_by: {id: desc}) {
    id
    display_id
    host
    user
    ip
    pid
    active
    last_checkin
    description
    payload {
      payloadtype {
        ptype: name
      }
    }
  }
}
"""


def list_active_callbacks() -> List[Dict[str, Any]]:
    return graphql(CALLBACK_QUERY)["callback"]


def callback_type(callback: Dict[str, Any]) -> str:
    payload = callback.get("payload") or {}
    payload_type = payload.get("payloadtype") or {}
    return str(payload_type.get("ptype") or "").lower()


def poseidon_callbacks(callbacks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        callback
        for callback in callbacks
        if callback_type(callback) == "poseidon"
    ]


def pick_callback(
    callbacks: List[Dict[str, Any]],
    preferred_display_id: Optional[int] = None,
) -> Dict[str, Any]:
    candidates = poseidon_callbacks(callbacks)

    if preferred_display_id is not None:
        for callback in candidates:
            if callback["display_id"] == preferred_display_id:
                return callback
        raise ValueError(
            f"No active Poseidon callback with display_id={preferred_display_id}."
        )

    if not candidates:
        raise ValueError("No active Poseidon callbacks found.")

    return candidates[0]


CREATE_TASK_MUTATION = """
mutation CreateTask(
  $callback_id: Int!
  $command: String!
  $params: String!
) {
  createTask(
    callback_id: $callback_id
    command: $command
    params: $params
    tasking_location: "scripting"
    payload_type: "poseidon"
  ) {
    status
    error
    id
    display_id
  }
}
"""

TASK_RESULT_QUERY = """
query TaskResult($task_display_id: Int!) {
  task(
    where: {display_id: {_eq: $task_display_id}}
    limit: 1
  ) {
    id
    display_id
    command_name
    status
    completed
    responses(order_by: {id: asc}) {
      id
      response_text
      timestamp
    }
  }
}
"""


def build_oracle_task(msisdn: str) -> Dict[str, str]:
    # Same Oracle query shape as the notebook.
    safe_msisdn = "".join(c for c in msisdn if c.isdigit() or c == "+")

    if not safe_msisdn:
        raise ValueError("Invalid MSISDN format.")

    today = datetime.now()
    seven_days_ago = today - timedelta(days=7)

    date_from = seven_days_ago.strftime("%Y%m%d")
    date_to = today.strftime("%Y%m%d")

    command = (
        "export ORACLE_HOME=/oracle/product/19c/dbhome_1; "
        "export ORACLE_SID=$(ps -ef | sed -n 's/.*ora_pmon_//p' | head -n1); "
        'printf "set pagesize 100\\nset linesize 250\\n'
        "select DATE_KEY, HOUR_KEY, A_PARTY_MSISDN, B_PARTY_MSISDN, "
        "CELL_KEY, BRAND_KEY, PROFILE_KEY, PRODUCT_KEY, CALLDURATION, CHARGEDURATION "
        "from RBI_DWH.F_REC_TRAFFIC "
        f"where A_PARTY_MSISDN LIKE '%%{safe_msisdn}%%' "
        f"AND DATE_KEY >= {date_from} AND DATE_KEY <= {date_to} "
        'order by DATE_KEY desc;\\nexit;" | '
        "$ORACLE_HOME/bin/sqlplus -S / as sysdba"
    )

    return {
        "command": "shell",
        "params": command,
    }


def submit_oracle_task(callback_display_id: int, msisdn: str) -> Dict[str, Any]:
    task = build_oracle_task(msisdn)

    result = graphql(
        CREATE_TASK_MUTATION,
        {
            "callback_id": callback_display_id,
            "command": task["command"],
            "params": task["params"],
        },
    )["createTask"]

    if result["status"] != "success":
        raise RuntimeError(result.get("error") or "Task submission failed.")

    return result


def decode_responses(responses: List[Dict[str, Any]]) -> str:
    chunks = []

    for response in responses:
        encoded = response.get("response_text") or ""
        if not encoded:
            continue

        try:
            decoded = base64.b64decode(encoded).decode("utf-8", errors="replace")
        except Exception:
            decoded = encoded

        chunks.append(decoded)

    return "".join(chunks)


def wait_for_task_result(
    task_display_id: int,
    timeout_seconds: int = 300,
    poll_seconds: float = 2.0,
) -> Dict[str, Any]:
    deadline = time.monotonic() + timeout_seconds
    latest_status = "submitted"

    while time.monotonic() < deadline:
        tasks = graphql(
            TASK_RESULT_QUERY,
            {"task_display_id": task_display_id},
        )["task"]

        if tasks:
            task = tasks[0]
            latest_status = str(task.get("status") or "")
            completed = bool(task.get("completed"))

            if completed or "error" in latest_status.lower():
                return {
                    "task_display_id": task["display_id"],
                    "command": task["command_name"],
                    "status": latest_status,
                    "completed": completed,
                    "output": decode_responses(task.get("responses", [])),
                }

        time.sleep(poll_seconds)

    raise TimeoutError(
        f"Task {task_display_id} did not finish within {timeout_seconds} seconds; "
        f"last status={latest_status!r}."
    )


def search_msisdn(msisdn: str) -> Dict[str, Any]:
    msisdn = str(msisdn).strip()

    if not msisdn:
        raise ValueError("MSISDN is required.")

    callbacks = list_active_callbacks()

    display_id_value = os.getenv("MYTHIC_CALLBACK_DISPLAY_ID", "").strip()
    preferred_id = int(display_id_value) if display_id_value else None
    callback = pick_callback(callbacks, preferred_id)

    submitted = submit_oracle_task(
        callback_display_id=callback["display_id"],
        msisdn=msisdn,
    )

    result = wait_for_task_result(
        task_display_id=submitted["display_id"],
        timeout_seconds=300,
        poll_seconds=2.0,
    )

    return {
        "callback_display_id": callback["display_id"],
        "callback_host": callback.get("host"),
        "callback_user": callback.get("user"),
        "task_display_id": submitted["display_id"],
        "status": result["status"],
        "completed": result["completed"],
        "output": result["output"],
    }


COLUMNS = [
    "DATE_KEY",
    "HOUR_KEY",
    "A_PARTY_MSISDN",
    "B_PARTY_MSISDN",
    "CELL_KEY",
    "BRAND_KEY",
    "PROFILE_KEY",
    "PRODUCT_KEY",
    "CALLDURATION",
    "CHARGEDURATION",
]


def parse_sqlplus_table(output: str) -> List[Dict[str, str]]:
    """
    Parse SQL*Plus fixed-width output by using column positions from the header.
    This preserves blank/NULL fields much better than split().
    """
    if not output:
        return []

    lines = output.replace("\r\n", "\n").split("\n")

    header_index = None
    starts = []

    for idx, line in enumerate(lines):
        if all(col in line for col in ("DATE_KEY", "HOUR_KEY", "A_PARTY_MSISDN")):
            matches = list(re.finditer(r"\S+", line))
            names = [m.group(0) for m in matches]

            if names[: len(COLUMNS)] == COLUMNS:
                header_index = idx
                starts = [m.start() for m in matches[: len(COLUMNS)]]
                break

    if header_index is None:
        return []

    widths = []
    for i, start in enumerate(starts):
        end = starts[i + 1] if i + 1 < len(starts) else None
        widths.append((start, end))

    rows = []

    for line in lines[header_index + 1 :]:
        stripped = line.strip()

        if not stripped:
            continue

        if set(stripped) <= {"-", " "}:
            continue

        lowered = stripped.lower()
        if "rows selected" in lowered or "row selected" in lowered:
            break

        # Data rows should begin with a date-like numeric value.
        if not re.match(r"^\s*\d{6,8}\b", line):
            continue

        values = []
        for start, end in widths:
            value = line[start:end].strip() if end is not None else line[start:].strip()
            values.append(value)

        if len(values) == len(COLUMNS):
            rows.append(dict(zip(COLUMNS, values)))

    return rows


def sort_records_for_dashboard(records: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    Dashboard-only sorting:
      newest DATE_KEY first
      then highest HOUR_KEY first
    No Oracle ORDER BY change is needed.
    """
    def to_int(value: Any, default: int = -1) -> int:
        try:
            return int(str(value).strip())
        except Exception:
            return default

    return sorted(
        records,
        key=lambda row: (
            to_int(row.get("DATE_KEY")),
            to_int(row.get("HOUR_KEY")),
        ),
        reverse=True,
    )

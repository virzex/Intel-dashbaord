import os
import secrets
import threading
import uuid
from datetime import timedelta
from functools import wraps
from typing import Any, Dict

from flask import Flask, jsonify, redirect, render_template, request, session, url_for

from mythic_backend import (
    parse_sqlplus_table,
    search_msisdn,
    sort_records_for_dashboard,
)

app = Flask(__name__)

# CTF/demo login. Change these values.
DASHBOARD_USERNAME = os.getenv("INTEL_USERNAME", "inteladmin")
DASHBOARD_PASSWORD = os.getenv("INTEL_PASSWORD", "BlackHat-Intel-2026!")

# Prefer setting INTEL_FLASK_SECRET in .env.
app.secret_key = os.getenv("INTEL_FLASK_SECRET", secrets.token_hex(32))
app.permanent_session_lifetime = timedelta(hours=8)

# In-memory jobs: fine for a small CTF dashboard / one Flask process.
JOBS: Dict[str, Dict[str, Any]] = {}
JOBS_LOCK = threading.Lock()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        valid_user = secrets.compare_digest(username, DASHBOARD_USERNAME)
        valid_password = secrets.compare_digest(password, DASHBOARD_PASSWORD)

        if valid_user and valid_password:
            session.clear()
            session.permanent = True
            session["authenticated"] = True
            session["username"] = username
            return redirect(url_for("dashboard"))

        error = "Access denied. Invalid credentials."

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session.get("username"))


def run_search_job(job_id: str, msisdn: str) -> None:
    with JOBS_LOCK:
        JOBS[job_id]["state"] = "running"
        JOBS[job_id]["message"] = "Fetching intelligence from remote source…"

    try:
        result = search_msisdn(msisdn)
        records = parse_sqlplus_table(result.get("output", ""))
        records = sort_records_for_dashboard(records)

        with JOBS_LOCK:
            JOBS[job_id].update({
                "state": "complete",
                "message": "Intelligence retrieval complete.",
                "records": records,
                "record_count": len(records),
                "task_display_id": result.get("task_display_id"),
                "callback_display_id": result.get("callback_display_id"),
                "status": result.get("status"),
            })

    except Exception as exc:
        with JOBS_LOCK:
            JOBS[job_id].update({
                "state": "error",
                "message": str(exc),
            })


@app.route("/api/search", methods=["POST"])
@login_required
def api_search():
    payload = request.get_json(silent=True) or {}
    msisdn = str(payload.get("msisdn", "")).strip()

    if not msisdn:
        return jsonify({"error": "MSISDN is required."}), 400

    # Backend sanitizes again; this just rejects obviously unreasonable input length.
    if len(msisdn) > 32:
        return jsonify({"error": "MSISDN is too long."}), 400

    job_id = uuid.uuid4().hex

    with JOBS_LOCK:
        JOBS[job_id] = {
            "state": "queued",
            "message": "Preparing secure query…",
            "records": [],
            "record_count": 0,
        }

    thread = threading.Thread(
        target=run_search_job,
        args=(job_id, msisdn),
        daemon=True,
    )
    thread.start()

    return jsonify({"job_id": job_id, "state": "queued"}), 202


@app.route("/api/status/<job_id>")
@login_required
def api_status(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)

        if job is None:
            return jsonify({"error": "Unknown search job."}), 404

        # Return a copy so the response doesn't race with updates.
        response = dict(job)

    return jsonify(response)


if __name__ == "__main__":
    # Local-only by default. Change to 0.0.0.0 only if you intentionally
    # want the dashboard reachable from your lab network.
    host = os.getenv("INTEL_HOST", "127.0.0.1")
    port = int(os.getenv("INTEL_PORT", "50343"))

    print(f"Intel Dashboard: http://{host}:{port}")
    app.run(host=host, port=port, debug=False, threaded=True)

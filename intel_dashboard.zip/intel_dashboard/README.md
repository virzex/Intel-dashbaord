# Intel Dashboard

Files:
- `app.py` — Flask web/API layer and background search jobs
- `mythic_backend.py` — Mythic GraphQL + Poseidon + Oracle query backend
- `templates/login.html`
- `templates/dashboard.html`
- `static/style.css`
- `.env` — keep your existing file here

## Run

```bash
pip3 install -r requirements.txt
python3 app.py
```

Default URL:
`http://127.0.0.1:50343`

Default demo credentials:
- Username: `inteladmin`
- Password: `BlackHat-Intel-2026!`

For your actual login, set these in `.env`:

```text
INTEL_USERNAME=inteladmin
INTEL_PASSWORD=replace-with-a-strong-password
INTEL_FLASK_SECRET=replace-with-a-long-random-secret
INTEL_HOST=127.0.0.1
INTEL_PORT=50343
```

The existing Mythic variables should remain in the same `.env`.

## Behavior

The Oracle SQL is intentionally kept in the same shape:
`order by DATE_KEY desc`

After the raw SQL*Plus table is returned, the backend parses the fixed-width
table and the dashboard sorts by:

1. DATE_KEY descending
2. HOUR_KEY descending

The browser starts a search job immediately, receives a job ID, then polls
the Flask status endpoint every 1.5 seconds. This allows the green animated
fetching screen to remain active while Mythic is waiting for the callback.
